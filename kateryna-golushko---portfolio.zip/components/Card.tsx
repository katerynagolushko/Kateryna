import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
}

export const Card: React.FC<CardProps> = ({ children, className = "", title }) => {
  return (
    <div className={`bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm hover:shadow-md transition-shadow duration-300 ${className}`}>
      {title && <h3 className="text-xl font-semibold text-slate-900 mb-4">{title}</h3>}
      {children}
    </div>
  );
};